--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1 (Ubuntu 15.1-1.pgdg20.04+1)
-- Dumped by pg_dump version 15.1 (Ubuntu 15.1-1.pgdg20.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE alessandro;
--
-- Name: alessandro; Type: DATABASE; Schema: -; Owner: alessandro
--

CREATE DATABASE alessandro WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE alessandro OWNER TO alessandro;

\connect alessandro

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bevanda; Type: TABLE; Schema: public; Owner: alessandro
--

CREATE TABLE public.bevanda (
    nome text NOT NULL,
    codice_bevanda integer NOT NULL,
    prezzo real NOT NULL
);


ALTER TABLE public.bevanda OWNER TO alessandro;

--
-- Name: cliente; Type: TABLE; Schema: public; Owner: alessandro
--

CREATE TABLE public.cliente (
    nome text NOT NULL,
    telefono character varying,
    idcliente integer NOT NULL
);


ALTER TABLE public.cliente OWNER TO alessandro;

--
-- Name: cliente_idcliente_seq; Type: SEQUENCE; Schema: public; Owner: alessandro
--

ALTER TABLE public.cliente ALTER COLUMN idcliente ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.cliente_idcliente_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: coupon; Type: TABLE; Schema: public; Owner: alessandro
--

CREATE TABLE public.coupon (
    codice_sconto character varying NOT NULL,
    valore integer NOT NULL
);


ALTER TABLE public.coupon OWNER TO alessandro;

--
-- Name: ingred_pizza; Type: TABLE; Schema: public; Owner: alessandro
--

CREATE TABLE public.ingred_pizza (
    ingrediente text NOT NULL,
    codice_pizza integer NOT NULL
);


ALTER TABLE public.ingred_pizza OWNER TO alessandro;

--
-- Name: ordine_bevanda; Type: TABLE; Schema: public; Owner: alessandro
--

CREATE TABLE public.ordine_bevanda (
    n_pezzi integer NOT NULL,
    id_prenotazione integer NOT NULL,
    codice_bevanda integer NOT NULL
);


ALTER TABLE public.ordine_bevanda OWNER TO alessandro;

--
-- Name: ordine_pizza; Type: TABLE; Schema: public; Owner: alessandro
--

CREATE TABLE public.ordine_pizza (
    n_pezzi integer NOT NULL,
    id_prenotazione integer NOT NULL,
    codice_pizza integer NOT NULL
);


ALTER TABLE public.ordine_pizza OWNER TO alessandro;

--
-- Name: pizza; Type: TABLE; Schema: public; Owner: alessandro
--

CREATE TABLE public.pizza (
    nome text NOT NULL,
    codice_pizza integer NOT NULL,
    prezzo double precision NOT NULL
);


ALTER TABLE public.pizza OWNER TO alessandro;

--
-- Name: prenotazione; Type: TABLE; Schema: public; Owner: alessandro
--

CREATE TABLE public.prenotazione (
    id_prenotazione integer NOT NULL,
    data date NOT NULL,
    orario time without time zone NOT NULL,
    idcliente integer NOT NULL
);


ALTER TABLE public.prenotazione OWNER TO alessandro;

--
-- Name: prenotazione_id_prenotazione_seq; Type: SEQUENCE; Schema: public; Owner: alessandro
--

ALTER TABLE public.prenotazione ALTER COLUMN id_prenotazione ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.prenotazione_id_prenotazione_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: bevanda; Type: TABLE DATA; Schema: public; Owner: alessandro
--

COPY public.bevanda (nome, codice_bevanda, prezzo) FROM stdin;
\.
COPY public.bevanda (nome, codice_bevanda, prezzo) FROM '$$PATH$$/3376.dat';

--
-- Data for Name: cliente; Type: TABLE DATA; Schema: public; Owner: alessandro
--

COPY public.cliente (nome, telefono, idcliente) FROM stdin;
\.
COPY public.cliente (nome, telefono, idcliente) FROM '$$PATH$$/3377.dat';

--
-- Data for Name: coupon; Type: TABLE DATA; Schema: public; Owner: alessandro
--

COPY public.coupon (codice_sconto, valore) FROM stdin;
\.
COPY public.coupon (codice_sconto, valore) FROM '$$PATH$$/3378.dat';

--
-- Data for Name: ingred_pizza; Type: TABLE DATA; Schema: public; Owner: alessandro
--

COPY public.ingred_pizza (ingrediente, codice_pizza) FROM stdin;
\.
COPY public.ingred_pizza (ingrediente, codice_pizza) FROM '$$PATH$$/3379.dat';

--
-- Data for Name: ordine_bevanda; Type: TABLE DATA; Schema: public; Owner: alessandro
--

COPY public.ordine_bevanda (n_pezzi, id_prenotazione, codice_bevanda) FROM stdin;
\.
COPY public.ordine_bevanda (n_pezzi, id_prenotazione, codice_bevanda) FROM '$$PATH$$/3380.dat';

--
-- Data for Name: ordine_pizza; Type: TABLE DATA; Schema: public; Owner: alessandro
--

COPY public.ordine_pizza (n_pezzi, id_prenotazione, codice_pizza) FROM stdin;
\.
COPY public.ordine_pizza (n_pezzi, id_prenotazione, codice_pizza) FROM '$$PATH$$/3381.dat';

--
-- Data for Name: pizza; Type: TABLE DATA; Schema: public; Owner: alessandro
--

COPY public.pizza (nome, codice_pizza, prezzo) FROM stdin;
\.
COPY public.pizza (nome, codice_pizza, prezzo) FROM '$$PATH$$/3382.dat';

--
-- Data for Name: prenotazione; Type: TABLE DATA; Schema: public; Owner: alessandro
--

COPY public.prenotazione (id_prenotazione, data, orario, idcliente) FROM stdin;
\.
COPY public.prenotazione (id_prenotazione, data, orario, idcliente) FROM '$$PATH$$/3383.dat';

--
-- Name: cliente_idcliente_seq; Type: SEQUENCE SET; Schema: public; Owner: alessandro
--

SELECT pg_catalog.setval('public.cliente_idcliente_seq', 87, true);


--
-- Name: prenotazione_id_prenotazione_seq; Type: SEQUENCE SET; Schema: public; Owner: alessandro
--

SELECT pg_catalog.setval('public.prenotazione_id_prenotazione_seq', 113, true);


--
-- Name: bevanda bevanda_pk; Type: CONSTRAINT; Schema: public; Owner: alessandro
--

ALTER TABLE ONLY public.bevanda
    ADD CONSTRAINT bevanda_pk PRIMARY KEY (codice_bevanda);


--
-- Name: cliente cliente_pk; Type: CONSTRAINT; Schema: public; Owner: alessandro
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_pk PRIMARY KEY (idcliente);


--
-- Name: coupon coupon_pk; Type: CONSTRAINT; Schema: public; Owner: alessandro
--

ALTER TABLE ONLY public.coupon
    ADD CONSTRAINT coupon_pk PRIMARY KEY (codice_sconto);


--
-- Name: ingred_pizza ingred_pizza_pk; Type: CONSTRAINT; Schema: public; Owner: alessandro
--

ALTER TABLE ONLY public.ingred_pizza
    ADD CONSTRAINT ingred_pizza_pk PRIMARY KEY (ingrediente, codice_pizza);


--
-- Name: ordine_bevanda ordine_bevanda_pk; Type: CONSTRAINT; Schema: public; Owner: alessandro
--

ALTER TABLE ONLY public.ordine_bevanda
    ADD CONSTRAINT ordine_bevanda_pk PRIMARY KEY (id_prenotazione, codice_bevanda);


--
-- Name: ordine_pizza ordine_pizza_pk; Type: CONSTRAINT; Schema: public; Owner: alessandro
--

ALTER TABLE ONLY public.ordine_pizza
    ADD CONSTRAINT ordine_pizza_pk PRIMARY KEY (id_prenotazione, codice_pizza);


--
-- Name: pizza pizza_pk; Type: CONSTRAINT; Schema: public; Owner: alessandro
--

ALTER TABLE ONLY public.pizza
    ADD CONSTRAINT pizza_pk PRIMARY KEY (codice_pizza);


--
-- Name: prenotazione prenotazione_pk; Type: CONSTRAINT; Schema: public; Owner: alessandro
--

ALTER TABLE ONLY public.prenotazione
    ADD CONSTRAINT prenotazione_pk PRIMARY KEY (id_prenotazione);


--
-- Name: ingred_pizza ingred_pizza_fk; Type: FK CONSTRAINT; Schema: public; Owner: alessandro
--

ALTER TABLE ONLY public.ingred_pizza
    ADD CONSTRAINT ingred_pizza_fk FOREIGN KEY (codice_pizza) REFERENCES public.pizza(codice_pizza);


--
-- Name: ordine_bevanda ordine_bevanda_fk; Type: FK CONSTRAINT; Schema: public; Owner: alessandro
--

ALTER TABLE ONLY public.ordine_bevanda
    ADD CONSTRAINT ordine_bevanda_fk FOREIGN KEY (id_prenotazione) REFERENCES public.prenotazione(id_prenotazione);


--
-- Name: ordine_bevanda ordine_bevanda_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: alessandro
--

ALTER TABLE ONLY public.ordine_bevanda
    ADD CONSTRAINT ordine_bevanda_fk_1 FOREIGN KEY (codice_bevanda) REFERENCES public.bevanda(codice_bevanda);


--
-- Name: ordine_pizza ordine_pizza_fk; Type: FK CONSTRAINT; Schema: public; Owner: alessandro
--

ALTER TABLE ONLY public.ordine_pizza
    ADD CONSTRAINT ordine_pizza_fk FOREIGN KEY (id_prenotazione) REFERENCES public.prenotazione(id_prenotazione);


--
-- Name: ordine_pizza ordine_pizza_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: alessandro
--

ALTER TABLE ONLY public.ordine_pizza
    ADD CONSTRAINT ordine_pizza_fk_1 FOREIGN KEY (codice_pizza) REFERENCES public.pizza(codice_pizza);


--
-- Name: prenotazione prenotazione_fk; Type: FK CONSTRAINT; Schema: public; Owner: alessandro
--

ALTER TABLE ONLY public.prenotazione
    ADD CONSTRAINT prenotazione_fk FOREIGN KEY (idcliente) REFERENCES public.cliente(idcliente);


--
-- PostgreSQL database dump complete
--

